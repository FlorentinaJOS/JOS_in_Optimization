function out=BenF(BFid,x)
switch BFid
    case 1 %sphere
        [pop,var]=size(x);
        for i=1:pop
            for j=1:var
                y =sum(x(i,:).^2);
            end
            out(i)=y;
        end
    case 2 %sumsquares
        [pop,var]=size(x);
        for i=1:pop
            for j=1:var
                y =sum(j*(x(i,:).^2));
            end
            out(i)=y;
        end
    case 3 %beale
        [pop,var]=size(x);
        for i=1:pop
                x1=x(i,1);
                x2=x(i,2);
                y =sum((1.5-(x1.*(1-x2))).^2)+...
                    ((2.25-(x1.*(1-(x2^2)))).^2)+...
                    ((2.625-(x1.*(1-(x2^3)))).^2);
            out(i)=y;
        end
    case 4
        [pop,var]=size(x);
        for i=1:pop
            for j=1:var
                x1=x(i,1);
                x2=x(i,2);
                y=-cos(x1).*cos(x2).*exp(-((x1-pi).^2+(x2-pi).^2));
            end
            out(i)=y;
        end
        
end
end